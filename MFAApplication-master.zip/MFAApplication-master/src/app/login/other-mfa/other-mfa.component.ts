import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-mfa',
  templateUrl: './other-mfa.component.html',
  styleUrls: ['./other-mfa.component.scss']
})
export class OtherMfaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
