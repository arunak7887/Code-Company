# Mfaapplication

Application developed using Angular 14 and Bootstrap.

## Components involved.
  - Login
  - Register
  - TOTP
  - Home Module


