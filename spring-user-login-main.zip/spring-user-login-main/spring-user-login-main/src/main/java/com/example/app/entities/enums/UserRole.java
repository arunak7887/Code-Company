package com.example.app.entities.enums;

public enum UserRole {
    USER,
    ADMIN
}
