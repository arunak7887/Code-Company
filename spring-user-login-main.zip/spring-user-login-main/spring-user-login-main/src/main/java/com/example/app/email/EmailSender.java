package com.example.app.email;

public interface EmailSender {
    void send(String to, String emailBody);
}
