package com.anbu.mfaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MfaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfaServerApplication.class, args);
	}

}
