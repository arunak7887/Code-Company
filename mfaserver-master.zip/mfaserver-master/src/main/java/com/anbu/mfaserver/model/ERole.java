package com.anbu.mfaserver.model;

public enum ERole {
    USER,
    ADMIN
}
