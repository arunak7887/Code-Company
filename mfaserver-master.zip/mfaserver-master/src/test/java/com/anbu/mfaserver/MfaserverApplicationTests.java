package com.anbu.mfaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
