## MFA Server
Application for 2FA demo. 
### APIs Involved
  -  login
  -  register
  -  verifyTotp
  -  confrim-email
### Dependencies
  - Spring Security
  - Spring Web
  - dev.samstevens.totp
